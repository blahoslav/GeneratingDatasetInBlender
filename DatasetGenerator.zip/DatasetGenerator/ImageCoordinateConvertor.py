#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 15:20:30 2019

@author: blahoslav
"""

import bpy
import bpy_extras
from mathutils import Matrix, Vector
# Get the world coordinates of point_x, point_y and point_z

def getWorldVectorCoordinateOfObjectOnScene(nameOfObject):
    obj = bpy.data.objects[nameOfObject]  
    objectWorldVector = []
    objectWorldMatrix = obj.matrix_world 
    objectWorldCoordinates = []
    for row in objectWorldMatrix:
      objectWorldCoordinates.append(row[3])
    objectWorldVector = Vector(objectWorldCoordinates)
    return objectWorldVector

#---------------------------------------------------------------
# 3x4 P matrix from Blender camera
#---------------------------------------------------------------
# Build intrinsic camera parameters from Blender camera data

def getCalibrationMatrixKFromBlender(camd):
    f_in_mm = camd.lens
    scene = bpy.context.scene
    resolution_x_in_px = scene.render.resolution_x
    resolution_y_in_px = scene.render.resolution_y
    scale = scene.render.resolution_percentage / 100
    sensor_width_in_mm = camd.sensor_width
    sensor_height_in_mm = camd.sensor_height
    pixel_aspect_ratio = scene.render.pixel_aspect_x / scene.render.pixel_aspect_y
    if (camd.sensor_fit == 'VERTICAL'):
        # the sensor height is fixed (sensor fit is horizontal), 
        # the sensor width is effectively changed with the pixel aspect ratio
        s_u = resolution_x_in_px * scale / sensor_width_in_mm / pixel_aspect_ratio 
        s_v = resolution_y_in_px * scale / sensor_height_in_mm
    else: # 'HORIZONTAL' and 'AUTO'
        # the sensor width is fixed (sensor fit is horizontal), 
        # the sensor height is effectively changed with the pixel aspect ratio
        pixel_aspect_ratio = scene.render.pixel_aspect_x / scene.render.pixel_aspect_y
        s_u = resolution_x_in_px * scale / sensor_width_in_mm
        s_v = resolution_y_in_px * scale * pixel_aspect_ratio / sensor_height_in_mm
    
    # Parameters of intrinsic calibration matrix K
    alpha_u = f_in_mm * s_u
    alpha_v = f_in_mm * s_v
    u_0 = resolution_x_in_px * scale / 2
    v_0 = resolution_y_in_px * scale / 2
    skew = 0 # only use rectangular pixels

    K = Matrix(
        ((alpha_u, skew,    u_0),
        (    0  , alpha_v, v_0),
        (    0  , 0,        1 )))
    return K

# Returns camera rotation and translation matrices from Blender.
# 
# There are 3 coordinate systems involved:
#    1. The World coordinates: "world"
#       - right-handed
#    2. The Blender camera coordinates: "bcam"
#       - x is horizontal
#       - y is up
#       - right-handed: negative z look-at direction
#    3. The desired computer vision camera coordinates: "cv"
#       - x is horizontal
#       - y is down (to align to the actual pixel coordinates 
#         used in digital images)
#       - right-handed: positive z look-at direction
def get3x4RTMatrixFromBlender(cam):
    # bcam stands for blender camera
    R_bcam2cv = Matrix(
        ((1, 0,  0),
         (0, -1, 0),
         (0, 0, -1)))

    # Transpose since the rotation is object rotation, 
    # and we want coordinate rotation
    # R_world2bcam = cam.rotation_euler.to_matrix().transposed()
    # T_world2bcam = -1*R_world2bcam * location
    #
    # Use matrix_world instead to account for all constraints
    location, rotation = cam.matrix_world.decompose()[0:2]
    R_world2bcam = rotation.to_matrix().transposed()

    # Convert camera location to translation vector used in coordinate changes
    # T_world2bcam = -1*R_world2bcam*cam.location
    # Use location from matrix_world to account for constraints:     
    T_world2bcam = -1*R_world2bcam * location

    # Build the coordinate transform matrix from world to computer vision camera
    R_world2cv = R_bcam2cv*R_world2bcam
    T_world2cv = R_bcam2cv*T_world2bcam

    # put into 3x4 matrix
    RT = Matrix((
        R_world2cv[0][:] + (T_world2cv[0],),
        R_world2cv[1][:] + (T_world2cv[1],),
        R_world2cv[2][:] + (T_world2cv[2],)
         ))
    return RT

def get3x4PMatrixFromBlender(cam):
    K = getCalibrationMatrixKFromBlender(cam.data)
    RT = get3x4RTMatrixFromBlender(cam)
    return K*RT, K, RT

# ----------------------------------------------------------
# Alternate 3D coordinates to 2D pixel coordinate projection code
# adapted from https://blender.stackexchange.com/questions/882/how-to-find-image-coordinates-of-the-rendered-vertex?lq=1
# to have the y axes pointing up and origin at the top-left corner
# ----------------------------------------------------------
#if __name__ == "__main__":
#    # Insert your camera name here
#    cam = bpy.data.objects['Camera']
#    P, K, RT = get3x4PMatrixFromBlender(cam)
#    print("Parameters")
#    print("K")
#    print(K)
#    print("RT")
#    print(RT)
#    print("P")
#    print(P)
#    print("*************************************************")
#    print("Point x (in the units of m)")
#    e1 = getWorldVectorCoordinateOfObjectOnScene('point_x')
#    p1 = P * e1
#    p1 /= p1[2]
#    print("Projected as (in the units of px)")
#    print(p1)
#    print("*************************************************")
#    print("Point y")
#    e2 = getWorldVectorCoordinateOfObjectOnScene('point_y')
#    p2 = P * e2
#    p2 /= p2[2]
#    print("Projected as")
#    print(p2)
#    print("*************************************************")
#    print("Point z")
#    e3 = getWorldVectorCoordinateOfObjectOnScene('point_z')
#    p3 = P * e3
#    p3 /= p3[2]
#    print("Projected as")
#    print(p3)